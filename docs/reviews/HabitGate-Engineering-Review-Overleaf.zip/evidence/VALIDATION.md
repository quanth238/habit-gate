# Validation — 18 October 2026

## Delivered

- Redesigned the Chrome blocked page and popup with a responsive two-column desktop layout, larger headline, numbered habit rows, progress ring, local shield branding, clearer habit-date/reset facts and a compact sync footer. Installed frontend files were verified byte-for-byte against the source. Browser enforcement and native policy files are unchanged.
- Version 1.1.0 (build 4) added Mac app selection and a native blocked-app notice. Its five saved apps became active at **18 October 2026 at 04:00 local time**. The later 1.2.0 checks below reflect the current seven selected essentials and five active apps.
- Includes the installed blue shield-and-check application icon, with 16–1024 px representations and `CFBundleIconFile=AppIcon`. The installed bundle's signature and native messaging checks passed after the update; the relaunched app loaded its saved Keychain connection and successfully synced with Habitify. Existing habit policy and launch-at-login setting were retained.
- Release build of the native SwiftUI menu-bar app and native messaging helper completed successfully on this M1 Pro Mac running macOS 27.0.1.
- Installed `/Applications/Habit Gate.app`, registered the owner-only Chrome native messaging manifest, and copied the unpacked extension into `~/Library/Application Support/HabitGate/ChromeExtension`.
- Verified the installed app's ad-hoc code signature and executable dependencies. The app and helper depend on system frameworks and Swift runtime libraries, with no dependency on the build directory. The version 1.1.0 app bundle is approximately 2.1 MB.
- Opened and visually inspected the real native connection screen. Native Quiet is the implemented style, with automatic system appearance.
- Generated and reviewed three illustrative concept boards using the built-in image-generation tool: Native Quiet (`native-quiet-v2.png`), Focus Dark, and Paper Study. The final Native Quiet board corrects the initial board's unrelated browser address to Facebook.

## Automated checks passed

**28 Swift tests and 8 JavaScript tests — 36 total.**

- Daily gates: complete, incomplete, partial progress, skipped, failed, unknown, undone, missing and duplicate journal entries.
- Multiple essential habits, confirmed rest days, missing/archived habits, unsupported weekly goals and bad habits.
- Midnight and the exact 03:59:59 → 04:00 boundary, expiration of offline proof, clock rollback, timezone changes, and 23/25-hour daylight-saving days.
- Daily, weekday, month-date and interval schedules; malformed schedules; domain normalization, subdomains and lookalikes.
- Atomic snapshot roundtrip, file permissions, invalid cache rejection, deferred policy edits and pending-policy rebasing after timezone changes.
- Mock API transport: GET-only requests, authentication header, paginated habit retrieval, explicit journal date, partial progress, 401/403/429/500 errors, Retry-After, sanitized error messages, malformed responses and duplicate entries.
- Mock browser adapter: native state → declarative rules, script registration at document start, replacement of installation defaults, allow/block transitions, offline proof expiry, and rejection of privileged commands from content scripts.
- Mac app policy migration and persistence, exact bundle identity, protected system/Habitify apps, deferred additions/removals, and preservation of habit/website rules.
- App guard: selected apps only, foreground notice versus quiet background hiding, verified unlock and expiry, repeated activation, terminated apps, failed hide reporting, independent per-app failures, and concurrent hide/activation races.

Additional installed-protocol checks passed: fixed extension identity, native host registration, native message framing, unauthorized-origin rejection, oversized-message rejection and no credential fields in the snapshot response. These checks run the installed helper directly; they do not establish that Chrome loaded the extension.

Reproduce with `./scripts/test.sh`. After installation, run `python3 scripts/check-install.py` for the installed protocol checks.

## Real Mac app guard check

A disposable, empty native app was used to exercise the actual macOS application events and hide API, without touching the user's five selected apps or changing any Habitify data. All five integration checks passed: launch hidden, verified proof permits the window, an undo hides the open window, trying to unhide it is intercepted, and the fixture process/session remains alive. Four foreground notices were observed with no protection errors. The verified proof in this isolated harness was synthetic; this is not a live Habitify completion/unlock test.

The first integration run found a launch race in which macOS rejected an early hide request before later hiding the window. The final guard waits for foreground activation to explain a launch and makes two bounded retries before reporting a failure. The corrected integration run and full automated suite passed.

## Measured resource use

One **60.14-second** sample, with the native setup window open and the app unconfigured:

| Measurement | Result |
|---|---:|
| Average CPU, percent of one core | 0.050% |
| Mean resident memory | 95.66 MB |
| Peak sampled resident memory | 99.94 MB |
| Samples | 58 |

This first sample covered setup only. A second 65.24-second sample taken while activating the app and interacting with settings measured 0.521% CPU, 85.99 MB mean RSS and 88.16 MB peak RSS; its CPU narrowly exceeded the idle target during interaction.

After activation, with settings closed, three populated essentials, authenticated periodic sync, and one loaded Chrome profile, a **65.32-second** idle sample measured:

| Measurement | Result |
|---|---:|
| Sampled average native CPU, percent of one core | 0.367% |
| Mean resident memory | 86.67 MB |
| Peak sampled resident memory | 87.41 MB |
| Samples | 63 |

Chrome launches the native helper only briefly. A separate real `getState` exchange measured with `/usr/bin/time -l` completed in 0.01 seconds and peaked at 10.78 MB RSS. Adding this helper peak to the sampled app peak gives 98.19 MB; this is a sum of separately measured peaks, not a continuous simultaneous measurement. The one-second profiler can miss a short-lived helper's CPU and memory. The observed app idle CPU and this memory estimate fall within the requested budgets, but these short samples do not establish a sustained combined-process guarantee. Reproduce the idle sample with `python3 scripts/profile.py --seconds 65`.

### Version 1.1.0 with Mac app support

With application event observers registered, settings closed, Habitify connected and the five Mac apps saved for the next boundary, a 65.40-second sample measured **0.596% sampled CPU**, **83.19 MB mean RSS**, and **85.46 MB peak RSS** across 63 samples. This CPU sample is above the requested 0.5% target. The helper separately peaked at **10.75 MB RSS**; adding separately measured peaks gives **96.21 MB**, subject to the same sampling limits above. Native app enforcement was exercised in the disposable integration test; the user's five-app policy was still pending during idle profiling.

Raw integration and profile results are saved in `validation/`.

A longer pre-fix sample then measured **4.628% CPU**, **92.10 MB mean RSS**, and **136.18 MB peak RSS** over 125.53 seconds. A five-second process sample showed hidden SwiftUI views doing repeated layout and live relative-time formatting. Build 4 creates the Today view only when opened, releases its hosting controller on close, releases closed settings/blocked windows, and displays a static last-successful-sync time. These changes remove UI work while no panel is open. The saved app selection and Habitify connection were verified again after installation.

After this fix, a **65.79-second** sample following opening and closing Mac app settings measured **0.289% sampled CPU**, **48.79 MB mean RSS**, and **55.69 MB peak RSS** across 63 samples. Adding the separately measured helper peak of 10.75 MB gives **66.44 MB**. These observations are within the requested idle targets, subject to the transient-helper sampling limits and the five-app policy still being pending. The real enforcement path was verified using the disposable fixture. Raw final measurements are in `validation/native-app-idle-final-65s.json`.

## Live connection and activation

- A replacement key successfully fetched the real habit catalog and dated journal, then was saved in macOS Keychain through Habit Gate's secure setup screen. Real API access and response decoding are verified.
- Activated three daily essentials: Learn 20 English words, Review English vocabulary · 15 min, and Focused study · 60 min. Each currently has `inprogress` status, so the verified state is blocked with three habits remaining. Launch at login is enabled; unlock notifications are off.
- At the live check shortly after midnight on 18 October, the active habit date was correctly 17 October, expiring at 04:00 on 18 October (Asia/Ho_Chi_Minh). No habit progress or completion was changed to test unlocking.
- Habitify's official API V2 help article confirms that API key management is mobile-only under Settings → API Credentials. The desktop UI has no such option. Habit Gate's native connection instructions and setup guide were corrected to state this explicitly and link the official instructions.
- After manual loading, one Chrome profile reported a fresh native heartbeat with website permissions granted. Direct navigation to Facebook, Instagram, X, Twitter and `m.facebook.com` redirected to Habit Gate's blocked page, confirmed by live tab URLs and titles. An unrelated HTTPS site loaded normally. Private browsing is not enabled for that profile.
- A file scan found no plaintext Habitify API key in project/runtime browser files. The replacement key was absent from the bridge's recent container logs. The installed native protocol exposes only the snapshot and connection flags.
- Automatic browser approval rejected opening `chrome://extensions` because the browser tool only permits HTTP(S) URLs. No alternate automation surface was used to bypass that rejection. Manual installation steps are in README.md and the app's Chrome & app tab.
- Safari is not packaged or installed: this Mac has no valid Apple code-signing identity and only Command Line Tools. Safari is a deferred phase requiring signing and build prerequisites.

## Remaining live checks

Real-device completion → unlock → undo → re-lock, cross-device cloud propagation, redirect chains and existing-tab enforcement, and actual sleep/wake and timezone transitions have not been exercised with live user data. Relevant policy and adapter cases pass automated tests. These live scenarios should not be claimed as verified. Safari remains deferred.

## Chrome UI redesign checks

All eight existing browser policy/adapter tests passed after the frontend update, along with JavaScript syntax validation. The UI was rendered in a local HTTP preview with mock extension messaging and the current three habit names. Verified partial progress, completed, rest-day, offline, permission-required, connection-error, long-name and light-mode variants. Continue is hidden for partial, offline and unverified states, and visible for verified-complete/rest-day fixtures. These fixture states did not modify the real Habitify journal or native snapshot.

Desktop rendering was reviewed at 1440 × 960 and narrow rendering at 390 × 844. Long habit names wrap without horizontal overflow. The matching 380 px popup measures approximately 589 px tall with three habits, fitting a 600 px popup viewport. Tab navigation moves from Open Habitify to Sync now with a visible outline; the sync button is re-enabled after its request. Test viewport overrides were reset afterward. Results are saved in `validation/blocked-page-ui-checks.json`, with rendered screenshots in `design/`.

Automatic browser approval rejected refreshing the existing Chrome extension page because only HTTP(S) protocols are allowed. No alternate browser surface was used to bypass that rejection. The user subsequently refreshed the existing tab manually and confirmed that the new design appears. No alternate automation surface was used to access the extension page.

## Existing Orange Pi bridge

The Orange Pi Habit Bridge service was recovered and the rejected Habitify key replaced through its authenticated connection API. The API verified that the new key belongs to the existing mapped account. All seven mappings remained unchanged; existing ownership/history and write settings were preserved. A backup ran before replacement.

Read-only test run 6232 examined seven mappings and 14 dates with no proposed changes. Three warnings preserve Habitify progress not owned by the bridge: research and vocabulary on 16 October, and the workout week beginning 12 October. These are intentional protections, not continuing authentication failures. No Habitify writes were performed by the manual test.

The existing bridge's 05:00 day boundary remains in place. Habit Gate uses the requested 04:00 boundary. Between 04:00 and 05:00 they intentionally refer to different habit dates; changing historical bridge reconciliation is outside this repair.

## Native redesign · version 1.2.0 (build 5)

- Generated a high-fidelity native design board with the built-in imagegen tool, then implemented its visual language in SwiftUI. The concept and exact prompt are saved in `design/native-redesign/`.
- Replaced settings tabs with a sidebar, added an overview with progress and protection status, restyled the Today popover and blocked-app notice, and separated habits, websites, connection and preferences into focused sections. Light and dark colors follow macOS. Lists scroll rather than growing past the available screen.
- Reviewed light/dark UI fixtures for seven habits, completion, rest days, offline access, missing habits, long names and setup. The fixture preview uses an in-memory substitute store: no credentials, network requests, journal writes or policy persistence. Continue appears only for verified complete/rest-day fixtures. Missing and offline fixtures remain blocked. Habit accessibility labels expose names, progress and status.
- Release build and installed signature/protocol checks passed. The 28 native tests and eight browser tests passed. Browser code, API behavior and the saved active/pending policy model are unchanged.
- Verified the installed overview, website editor, Mac app selector and preferences against real local settings. The saved configuration file hash stayed identical: seven essentials, five apps and the same five domains. Launch at login was visibly on; unlock notifications were off.
- A real attempt to bring Discord forward was intercepted and showed the redesigned native notice. Manual Sync now visibly entered the syncing state and completed successfully at **11:34 local**, with no error and access still blocked. Screenshots are in `design/native-redesign/installed-*.png`.
- Startup explicitly retains its delegate and initializes the service once. Duplicate detection ignores exited processes and returns before entering AppKit for a live duplicate.

The first warm idle sample, after visiting settings and the blocked-app screen, measured **0.333% average CPU**, **101.77 MB mean RSS**, and **115.97 MB peak RSS** over **66.02 seconds**. This met the CPU target but exceeded the original memory target. The app selector was then changed to use system symbols rather than decoding full-resolution application icons. The before-optimization report is saved under `validation/native-redesign-before-icon-optimization.json`.

The user approved the final locally signed rebuild’s access to the existing Keychain item. Live Habitify synchronization resumed without error, with a successful check at **11:46 local**. The final installed overview, lighter app selector, website settings and Preferences were inspected again; launch at login remained on. A second live Discord activation was intercepted by the final build and showed the redesigned notice. The saved configuration hash remained identical. The computer-use tool had rejected access to SecurityAgent for safety reasons, and the system authorization was completed by the user without an alternate automation surface. The earlier apparent startup stall was the synchronous Keychain read waiting for that system authorization, rather than an API failure.


After Keychain approval, a final warm idle sample of the installed build ran for **65.21 seconds** with all Habit Gate windows closed, after visiting Overview, Mac apps, Preferences, Websites and the blocked-app notice. It measured **0.107% average CPU**, **122.31 MB mean RSS** and **122.75 MB peak RSS** across 63 samples. The CPU result meets the requested idle target. The conservative resident-memory result exceeds the original 100 MB target; the system-symbol change did not bring warm RSS under that budget. The report is `validation/native-redesign-final-idle-profile.json`.

A separate macOS process sample reported an app **physical footprint of 39.4M**, with **42.6M peak**. Physical footprint and RSS are different accounting measures; neither this app-only point sample nor a separately measured helper peak establishes a continuous combined-process memory guarantee. The final resident-memory target is therefore recorded as unmet. No further rebuild was performed after the user’s Keychain approval.


## Reliability update · version 1.2.1 (build 6)

- Moved Keychain reads and saves to a dedicated actor. Startup initializes the UI, app guard, daily timer and connection monitoring before beginning credential retrieval. The UI explains pending/unavailable access and offers a retry after failure. The cached proof’s expiry and policy remain unchanged.
- Added six credential regression tests: pending authorization allows app-guard work, a cached unlock still expires while authorization waits, duplicate reads are coalesced, a late read cannot overwrite a reconnect, denied/missing access are distinguished with sanitized errors and retry, and failed replacement preserves a usable in-memory key.
- Added three coverage tests: heartbeat/file-order changes are ignored, permission/private-coverage changes remain visible, and disconnected/replaced profiles remain visible.
- **37 Swift tests and eight browser tests passed — 45 total.** The release build, installed code signature and native bridge checks passed.
- The installed app connected successfully using the existing Keychain item. Manual sync completed at **12:06 local** without error. The journal timestamp advanced from **05:05:33 UTC** to **05:06:16 UTC**, while the unchanged catalog file’s modification timestamp stayed identical. The live result is saved in `validation/reliability-live-catalog-check.json`.
- Rechecked seven selected habits, five active Mac apps, the same website domains and enabled launch at login. The saved configuration hash remained identical. A real Discord activation was intercepted by the updated app. Screenshots are in `design/reliability/`.
- Slow/denied Keychain scenarios are controlled regression tests. The final live connection completed successfully, so an extended real authorization wait was not observed during this installation.


The final 1.2.1 warm idle sample ran for **65.02 seconds**, with the same main settings sections and blocked-app notice visited before closing all panels. It recorded **0.154% average CPU**, **107.06 MB mean RSS**, and **120.83 MB peak RSS** across 63 samples. A separate app-only macOS sample reported **39.1M physical footprint**, with **42.8M peak**. Background sync subsequently completed at **12:08 local** without error. The raw reports are `validation/reliability-idle-profile.json` and `validation/reliability-final-checks.json`.

The measured CPU remains below 0.5%; resident memory remains above the original 100 MB target. The lower mean RSS versus the earlier 122.31 MB sample is an observation from a short run, not evidence of a sustained reduction under identical system conditions. The confirmed improvements are responsive startup during credential access, preserved blocking/expiry semantics, fewer redundant UI updates and avoidance of unchanged catalog writes. No new browser permissions, Habitify writes or policy changes were introduced.

## Optimization decision

The experimental 1.2.2 event-driven refactor was reverted at the user's request for simplicity. Short samples did not establish a clear practical resource benefit. The original signed **1.2.1 (build 6)** binary and sources were restored, with the exact configuration hash preserved. The restored app connected successfully to Habitify, and native Preferences confirmed launch at login remains on. All **37 native and eight browser tests** passed again; installed signature and native-protocol checks passed. Details are in `validation/optimization-rollback.json`.

## Rule timing update · version 1.3.0 (build 8)

- Changed target policy edits to be monotonic during the active day: website/app additions apply immediately; removals stay guarded until the next 4 AM boundary. Habit edits remain deferred. Mixed saves, cancelling a removal, removing a just-added target, restart and timezone rebasing use the same rule. Existing pending additions migrate without activating pending habit changes.
- Separated habit and website saves so an unsaved draft in one screen cannot be committed by the other. Buttons now say Save websites / Save apps, while Save habits for next day remains. Notices identify which changes are delayed. Only-target edits preserve a valid same-day completion proof.
- **46 native tests and eight browser tests passed — 54 total.** Eight new core timing regressions and one app-guard integration regression cover immediate additions and deferred removals. Release builds for app/helper and installed signature/native protocol checks passed. Browser files are unchanged; no extension reload is required.
- The installed migration promoted the user's pending Messenger domain into active coverage while preserving the seven active habits, eight pending habits, five app selections and original pending boundary. The native snapshot includes Messenger. Habitify synchronization succeeded without changing journal progress. The user reported approving Chrome website access, but fresh heartbeats still report missing permission. Messenger is selected in native policy; browser coverage for the expanded list remains unconfirmed.
- A live Save websites check with a changed, unsaved habit draft preserved the complete stored configuration (seven active / eight pending habits). The UI draft was restored afterward. A real foreground Discord attempt was intercepted by the installed build.
- No new resource profile was taken for 1.3.0. The preceding 1.2.1 measurements are historical and must not be relabeled as measurements of this build.
