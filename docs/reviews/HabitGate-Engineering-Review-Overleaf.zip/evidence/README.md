# Habit Gate for Mac

A native SwiftUI menu-bar app plus a Chrome Manifest V3 extension. Your selected websites and Mac apps remain gated until all selected daily Habitify habits due on the active habit date are complete. There is no pause or exercise bypass.

## Start

The built app is in `dist/Habit Gate.app`. `scripts/install.sh` installs it in `/Applications/Habit Gate.app`, registers the per-user Chrome native messaging host, and copies the extension into:

`~/Library/Application Support/HabitGate/ChromeExtension`

1. In **Habitify on your phone**, open **Settings → API Credentials** to obtain a key. API key management is mobile-only; the Mac and web apps do not expose it. Use an existing saved key if available; generating a new key revokes the previous one, and the new key is shown only once. See [Habitify's official instructions](https://intercom.help/habitify-app/en/articles/6113937-use-habitify-api-v2). In **Habit Gate → Connection** on this Mac, paste the key into the secure field and choose **Verify & save in Keychain**. Do not send the key through chat. API access requires a paid Habitify plan. The app verifies both the habit list and dated journal before saving the key.
2. Use **Essential habits** to choose your daily essentials and **Websites** to edit domains, then **Activate protection**. Start with 2–4 habits. Weekly/monthly goals, bad habits, and unsupported end conditions are excluded.
3. In Chrome, manually open `chrome://extensions`, enable Developer mode, select **Load unpacked**, and choose the folder above. Install it in each profile you want to protect. The fixed extension ID is `gggclbgihkhajpchlbeakabkoaaelpdb`.
4. Open the extension once. It should show a working native connection. Grant permissions for any custom website domains. Private browsing is covered only if you enable **Allow in Incognito** in the extension details.
5. Complete habits in Habitify. Cloud updates are read every minute while the Mac is awake. **Sync now** requests an immediate check, subject to error backoff.
6. In **Mac apps**, choose installed apps or use **Add app…**, then **Save apps**. Newly added apps join today’s protection immediately. Removals stay protected until the next 4 AM boundary. Website additions use the same timing; Chrome normally picks up the new native policy within 30 seconds, with custom-domain permission required. Habitify, Habit Gate, Finder and essential system controls cannot be selected.

Safari is not installed or protected in this release. There is no Apple signing identity or full Xcode installation available on this Mac. Safari packaging is the next phase, not part of the installed Chrome coverage.

## Daily behavior

- A habit day runs from **4 AM to 4 AM in the Mac's local timezone**. Between midnight and 4 AM, the previous calendar date is used in the Habitify journal query. Enter late-night check-ins on that previous date in Habitify. The app always shows the queried date; Habitify itself resets at midnight.
- Only Habitify's `completed` status counts. Partial progress, `skipped`, `failed`, missing journal entries, and unknown statuses remain blocked. A successfully fetched undo re-locks access.
- Repeat schedules support daily, selected weekdays (Sunday = 0), selected month dates, and intervals from the habit start date. A verified rest day unlocks automatically. Selected habits that go missing, are archived, end, or become unsupported cause a configuration warning and remain blocked.
- The first activation is immediate. After activation, **habit changes wait until the next 4 AM**. **Website/app additions apply when saved**, using today’s existing habit proof. **Website/app removals wait until the next 4 AM**, including a target added earlier that same day. A mixed save adds new targets now while retaining removed targets until the boundary. A timezone change rebases the remaining pending changes. Existing pending target additions are promoted automatically on update.
- If Habitify or the native bridge becomes unavailable, already verified completion remains usable only until its original 4 AM expiry. Unverified states remain blocked. Rate limiting and connectivity errors use 1, 2, 5, then 15-minute retry delays, respecting a longer server Retry-After.
- A browser extension is voluntary enforcement: another unconfigured browser/profile, disabling permissions, or removing the extension can bypass it. The app reports connected profiles, not whole-Mac website coverage.
- Mac app protection is a voluntary foreground guard. While locked, selected apps' windows are hidden when they come forward, and a native notice shows the remaining habits. Already open selected apps are also hidden when access re-locks. Apps are not forcibly quit: drafts, chats, games and background activity can continue. This does not deny process execution, notifications, or background network access, and quitting Habit Gate bypasses it. If macOS refuses a hide request, the app reports that protection needs attention. On verified completion, the selected app can be opened normally or through **Continue** in the notice.

## Architecture and privacy

`GateCore` contains the date and schedule policy, pending settings, domain rules, and atomic persistence. The SwiftUI app owns Habitify calls and Keychain. `HabitGateBridge` uses length-prefixed Chrome native messaging and checks the fixed extension origin. The browser receives an expiring `GateSnapshot`, not credentials.

The API client performs GET requests only against `api.habitify.me/v2`. Redirects are rejected to avoid forwarding the key. Server bodies and request headers are excluded from displayed errors. Local settings and snapshots use owner-only file permissions. Browsing history is not collected. The blocked page retains the requested destination only in its own local URL so Continue can return there after verification.

Chrome uses declarative navigation redirects, first-party resource blocking, and selected-site document-start guards for existing pages, cached pages, focus, and expiry. Dynamic rules replace the installation defaults; removing a website in tomorrow's policy therefore takes effect correctly.

Mac app protection uses `NSWorkspace` application events and `NSRunningApplication.hide()`. The existing five-second housekeeping timer checks the foreground app and reset state; no fast process polling, Accessibility access, root daemon, or forced termination is used. Native app selections stay in the local policy and are not included in browser snapshots. Existing website-only policies migrate with an empty app selection.

Closed native panels release their SwiftUI views. The Today panel displays the last successful sync time without a continuously updating relative-time clock, keeping the menu-bar app quiet while its panels are closed.

## Build and test

Requires macOS 13+, Apple Silicon for the supplied binary, Swift Command Line Tools, and Node.js for extension tests. No external Swift packages or npm dependencies.

```sh
./scripts/test.sh
./scripts/build.sh
./scripts/install.sh
```

The test script explicitly loads the bundled Swift Testing macro plugin where needed by the macOS 27 Command Line Tools. Tests require the toolchain's Testing framework. The native UI explicitly uses SwiftUI's property wrapper to avoid needing the new State macro plugin from full Xcode.

Builds are locally ad-hoc signed and are not notarized distribution builds. Updating an installed app can require Keychain access to be allowed again. Quit the app before installing an update. Updating unpacked extension files requires choosing Reload in Chrome's extension page.

The app includes a blue shield-and-check icon in every standard macOS size. `Resources/AppIcon.icns` is bundled by the build script. To regenerate it from its native vector drawing source, run `./scripts/build-icon.sh`, then rebuild and install the app. The menu-bar icon stays a system template symbol so it remains readable in light and dark appearances.

## Visuals and validation

`design/` contains the three AI-generated concept boards: Native Quiet, Focus Dark, Paper Study. They use illustrative progress and are design explorations, not proof of a live Habitify connection. Native Quiet guides the implemented interface. `design/prompts.md` records the prompts and tool used.

The implemented Chrome blocked page now uses a responsive two-column composition, larger typography, numbered habit rows, a progress ring, and a compact sync footer. The extension popup uses the same palette and components. Both follow the system's light/dark appearance, with visible keyboard focus and reduced-motion support. Assets and system fonts are local. Hidden browser pages stop requesting their UI refresh until visible again; native habit verification and browser enforcement remain independent.

`design/blocked-page-redesign-dark.jpg` and `design/extension-popup-redesign.jpg` show the rendered UI in a local preview. The preview uses current habit data with mock extension messaging; alternate test states are illustrative. Frontend files are installed in the existing unpacked extension directory. Refresh an already open blocked page with Command-R after a UI update. Background or manifest changes still require reloading the extension itself.

See `VALIDATION.md` for actual build, tests, installation, browser, API, and performance results. Live API checks require your key and browser activation requires manual loading in Chrome.

## Native app redesign · 1.2.0

The native app follows the built-in imagegen concept in `design/native-redesign/imagegen-concept.png`. Its exact prompt is saved alongside it as `imagegen-prompt.txt`. The concept uses illustrative progress; the installed app reads live Habitify data.

The Today menu-bar panel, main window, connection setup and blocked-app notice share adaptive light/dark colors, a blue shield identity, numbered habit cards, segmented progress, clearer sync status and consistent actions. The main window has Overview, Essential habits, Websites, Mac apps, Connection and Preferences sections. Protection status appears above the full essentials list so a longer habit selection remains easy to scan. Longer lists scroll, and completed, skipped, failed, rest-day and configuration states have explicit text. System symbols keep the Mac app selector lightweight.

Open **Preferences** for launch at login and the optional unlock notification. Reopening Habit Gate from Applications opens the main window; closing its windows returns it to menu-bar operation. Policy, API access and browser enforcement remain unchanged. macOS may ask to approve access to the saved Keychain item after installing a locally signed update; complete that prompt on your Mac and never send passwords or keys through chat.

`installed-*.png` files in the design folder capture real installed screens; `*-preview.png` files are isolated, illustrative UI fixtures that never read credentials or change saved rules.

## Reliability and idle work · 1.2.1

The menu-bar interface and app guard start before reading Keychain. Credential reads and writes run on a separate actor, so a slow macOS approval cannot freeze the interface or delay the existing app rules. Cached verification keeps its normal daily expiry. Connection settings distinguish a missing key from unavailable Keychain access and provide a retry action; pending reads are coalesced and cannot overwrite a successfully reconnected key.

Unchanged Chrome heartbeat timestamps no longer invalidate the native interface; changes to connected profiles, website permissions and private-browsing coverage still appear. Habit lists are saved and published only when their contents change. The journal is still verified every 60 seconds, and the guard/reset housekeeping interval is unchanged.

## Rule timing · 1.3.0

Habits and target lists now have different save behavior. Essential habits still use **Save habits for next day**. Websites and apps use **Save websites** / **Save apps**: additions take effect now and removals wait until 4 AM. Saving one screen does not commit an unfinished draft on another screen. Notices distinguish saved habit changes from pending website/app removals. Today's completion proof is preserved when only targets change, so adding a target does not re-lock an already verified complete day.
