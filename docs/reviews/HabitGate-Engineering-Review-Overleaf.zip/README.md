# Habit Gate: Product & Engineering Review

An internal, Overleaf-ready review of the **macOS app v1.3.0 (build 8)** and Chrome extension v1.0.0, document revision **1.1**, dated **18 October 2026**.

Rule timing: habit edits take effect at the next local 4 AM; website/app additions apply when saved; removals wait until 4 AM. Chrome normally reads changes within 30 seconds and custom domains need permission.

## Read first

- CEO: executive brief, scope, interface review, release gates and decision worksheet.
- Engineering: detailed feature specifications (Sections 2.1–2.3), sequence diagram (3.1), business rules, contracts, architecture, reliability, security, testing and runbook.

The document contains **four editable vector diagrams**, **eight feature specifications**, **33 numbered acceptance criteria** and **ten screenshot figures**. Seven figures show fresh captures of the installed app; the Today fixture and two browser previews are clearly labeled illustrative. Acceptance criteria describe required release behavior; they do not imply that every case has passed live testing.

## Open in Overleaf

1. Choose New Project → Upload Project, then upload the provided Overleaf ZIP.
2. Select `main.tex` as the main document.
3. Use **pdfLaTeX** and a current TeX Live environment.
4. Recompile. Standard LaTeX packages and local images are included/referenced; no shell escape, private API or external font is required.

## Compile locally

Run from this folder with a normal TeX Live installation:

```sh
mkdir -p build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build main.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build main.tex
```

The second pass resolves contents, cross-references and page counts. Temporary build files are intentionally excluded from the Overleaf ZIP.

## What is included

- `main.tex`: document styling, front matter and section order.
- `sections/`: editable content; diagrams are native TikZ in the flow, state, sequence and architecture sections.
- `images/`: full-resolution screenshots and app icon. The PDF trims only unused canvas around the Today fixture.
- `evidence/`: copied validation reports, baseline source hashes, screenshot provenance and document QA metadata.

The app's source code remains in the separate HabitGate project; this documentation project records the installed update and does not itself rebuild the app.

## Review boundaries

Current implementation, automated evidence, live observations and proposed fixes are distinguished throughout. The review does not claim public readiness, an independent security audit, a battery guarantee or continuous compliance with the original memory budget. The experimental 1.2.2 optimization was reverted and is not part of the reviewed architecture.

This internal document includes personal example habit names. Replace them with synthetic data before public publication. No API key or password is included. The CEO decision worksheet is a static review template; no approval has been recorded.
